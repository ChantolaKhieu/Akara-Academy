package Elementary;

import javax.swing.*;
import java.awt.*;

public class FractionSim extends JPanel {

    Color color = new Color(214, 255, 253);

    public FractionSim(){
        setPreferredSize(new Dimension(1460,1024));
        setBackground(color);
        setLayout(new GridBagLayout());
    }
}
