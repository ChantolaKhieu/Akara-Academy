package Primary;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

public class CountingSim extends JPanel implements ActionListener {

    Color color = new Color(214, 255, 253);

    private final JPanel bottomPanel = new JPanel();
    private final JButton backButton = new JButton();
    private final JPanel topPanel = new JPanel();
    private final JPanel centerPanel = new JPanel();

    private final JPanel centerBoxPanel = new JPanel();

    public CountingSim(){
        setPreferredSize(new Dimension(1460,1024));
        setBackground(color);
        setLayout(new BorderLayout());

        customBackBtn();
        setCenterPanel();
        setBottomPanel();
    }

    public void customBackBtn(){
        ImageIcon backIcon = new ImageIcon("src/assets/back.png");
        backIcon = new ImageIcon(backIcon.getImage().
                getScaledInstance(60,60, BufferedImage.SCALE_SMOOTH));

        backButton.setIcon(backIcon);
        backButton.setFocusable(false);
        backButton.setBorderPainted(false);
        backButton.setContentAreaFilled(false);
        backButton.setHorizontalAlignment(JButton.LEFT);
        backButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        backButton.addActionListener(this);

        topPanel.setAlignmentX(JButton.LEFT_ALIGNMENT);
        topPanel.setPreferredSize(new Dimension(65,80));
        topPanel.add(backButton, FlowLayout.LEFT);
        topPanel.setBorder(new LineBorder(Color.green));
        topPanel.setBackground(Color.green);
        add(topPanel, BorderLayout.PAGE_START);
    }

    public void setCenterPanel(){
        centerPanel.setBackground(Color.pink);

        centerBoxPanel.setPreferredSize(new Dimension(600,500));
        centerBoxPanel.setBackground(Color.cyan);
        centerBoxPanel.setBorder(new LineBorder(Color.gray));
        centerPanel.setAlignmentY(JPanel.CENTER_ALIGNMENT);
        centerPanel.add(centerBoxPanel);
        add(centerPanel, BorderLayout.CENTER);
    }

    public void setBottomPanel(){
        bottomPanel.setBackground(Color.gray);
        bottomPanel.setPreferredSize(new Dimension(0,120));
        add(bottomPanel, BorderLayout.PAGE_END);
    }

    @Override
    public void actionPerformed(ActionEvent e){

    }
}
